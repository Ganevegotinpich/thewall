package com.example.thewall

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
